<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <title> Login </title>
  <link rel="stylesheet" href="loginstyle.css">
</head>

<body>



  <form class="box" action="index.html" method="post">
    <h1>Login</h1>
    <input type="text" name="Username" placeholder="Username">
    <input type="password" name="Password" placeholder="Password">
    <input type="submit" name="Login" value="Login">
  </form>


</body>

</html>